import React from 'react';
import ReactDOM from 'react-dom/client';
import ClerkRouter from './auth/ClerkRouter.jsx';
import './index.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <ClerkRouter />
  </React.StrictMode>
);
