import React from 'react';
import { ClerkProvider, SignIn, SignUp } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { shadcn } from '@clerk/themes';
import { Route, Router, Switch, useLocation } from 'wouter';
import App from '../App';

const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');
const clerkPublishableKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY
);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;

if (!clerkPublishableKey) {
  throw new Error('Missing VITE_CLERK_PUBLISHABLE_KEY. Configure Clerk Auth for this project.');
}

const clerkAppearance = {
  theme: shadcn,
  options: {
    logoPlacement: 'inside',
    logoLinkUrl: basePath || '/',
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
  },
  variables: {
    colorPrimary: '#2E6F40',
    colorForeground: '#22252A',
    colorMutedForeground: '#687168',
    colorDanger: '#B42318',
    colorBackground: '#FAF8F5',
    colorInput: '#FFFFFF',
    colorInputForeground: '#22252A',
    colorNeutral: '#D9DDD6',
    fontFamily: 'DM Sans, Inter, sans-serif',
    borderRadius: '0.75rem',
  },
  elements: {
    rootBox: 'w-full flex justify-center',
    cardBox: 'bg-[#FAF8F5] rounded-2xl w-[440px] max-w-full overflow-hidden border border-[#E2E2DC] shadow-lg',
    card: '!shadow-none !border-0 !bg-transparent !rounded-none',
    footer: '!shadow-none !border-0 !bg-transparent !rounded-none',
    headerTitle: 'text-[#22252A] font-bold',
    headerSubtitle: 'text-[#687168]',
    socialButtonsBlockButtonText: 'text-[#22252A] font-semibold',
    formFieldLabel: 'text-[#22252A] font-medium',
    footerActionLink: 'text-[#2E6F40] font-semibold',
    footerActionText: 'text-[#687168]',
    dividerText: 'text-[#687168]',
    identityPreviewEditButton: 'text-[#2E6F40]',
    formFieldSuccessText: 'text-[#2E6F40]',
    alertText: 'text-[#22252A]',
    logoBox: 'rounded-xl overflow-hidden',
    logoImage: 'w-11 h-11',
    socialButtonsBlockButton: 'border border-[#D9DDD6] rounded-lg bg-white hover:bg-[#F4F3EF]',
    formButtonPrimary: 'bg-[#2E6F40] hover:bg-[#255C34] text-white rounded-lg',
    formFieldInput: 'bg-white text-[#22252A] border-[#D9DDD6] rounded-lg',
    footerAction: 'text-[#687168]',
    dividerLine: 'bg-[#D9DDD6]',
    alert: 'border-[#E2E2DC] rounded-lg',
    otpCodeFieldInput: 'bg-white text-[#22252A] border-[#D9DDD6]',
    formFieldRow: 'text-[#22252A]',
    main: 'text-[#22252A]',
  },
};

function SignInPage() {
  return (
    <main className="flex min-h-screen items-center justify-center bg-background px-4 py-10">
      <SignIn
        routing="path"
        path={`${basePath}/sign-in`}
        signUpUrl={`${basePath}/sign-up`}
        fallbackRedirectUrl={basePath || '/'}
      />
    </main>
  );
}

function SignUpPage() {
  return (
    <main className="flex min-h-screen items-center justify-center bg-background px-4 py-10">
      <SignUp
        routing="path"
        path={`${basePath}/sign-up`}
        signInUrl={`${basePath}/sign-in`}
        fallbackRedirectUrl={basePath || '/'}
      />
    </main>
  );
}

function ClerkApplication() {
  const [, setLocation] = useLocation();
  const stripBase = (path) => (
    basePath && path.startsWith(basePath) ? path.slice(basePath.length) || '/' : path
  );

  return (
    <ClerkProvider
      publishableKey={clerkPublishableKey}
      proxyUrl={clerkProxyUrl}
      appearance={clerkAppearance}
      signInUrl={`${basePath}/sign-in`}
      signUpUrl={`${basePath}/sign-up`}
      localization={{
        signIn: { start: { title: 'Welcome back', subtitle: 'Sign in to your reuse studio' } },
        signUp: { start: { title: 'Create your account', subtitle: 'Start making more from less' } },
      }}
      routerPush={(to) => setLocation(stripBase(to))}
      routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
    >
      <Switch>
        <Route path="/sign-in/*?" component={SignInPage} />
        <Route path="/sign-up/*?" component={SignUpPage} />
        <Route component={App} />
      </Switch>
    </ClerkProvider>
  );
}

export default function ClerkRouter() {
  return (
    <Router base={basePath}>
      <ClerkApplication />
    </Router>
  );
}