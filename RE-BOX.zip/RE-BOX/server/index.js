import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { analyzeObject, generateBlueprint, chatWithAssistant } from './aiService.js';
import { getAllProjects, getProjectById, createProject, updateProject, deleteProject } from './projectStore.js';
import { clerkMiddleware, getAuth } from '@clerk/express';
import { publishableKeyFromHost } from '@clerk/shared/keys';
import { CLERK_PROXY_PATH, clerkProxyMiddleware, getClerkProxyHost } from './middlewares/clerkProxyMiddleware.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(CLERK_PROXY_PATH, clerkProxyMiddleware());
app.use(cors({ credentials: true, origin: true }));
app.use(express.json({ limit: '25mb' }));
app.use(express.urlencoded({ extended: true, limit: '25mb' }));
app.use(clerkMiddleware((req) => ({
  publishableKey: publishableKeyFromHost(
    getClerkProxyHost(req) ?? '',
    process.env.CLERK_PUBLISHABLE_KEY
  ),
})));

function requireAuth(req, res, next) {
  const { userId } = getAuth(req);
  if (!userId) return res.status(401).json({ error: 'Sign in to manage your saved projects.' });
  req.userId = userId;
  next();
}

// Health Check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'healthy',
    product: 'RE:BOX',
    version: '1.0.0',
    aiEngine: process.env.GEMINI_API_KEY ? 'gemini-vision-enabled' : 'smart-taxonomy-engine',
    timestamp: new Date().toISOString()
  });
});

// Object Analysis API (Step 1 -> Step 2 & 3)
app.post('/api/analyze-object', async (req, res) => {
  try {
    const { imageBase64, description, fileName } = req.body;

    // Validate that either an image or a description is provided
    if (!imageBase64 && (!description || description.trim().length === 0)) {
      return res.status(400).json({
        error: "We couldn't understand this object. Try uploading a clearer photo or typing a brief description."
      });
    }

    const result = await analyzeObject({ imageBase64, description, fileName });
    res.json(result);
  } catch (error) {
    console.error('Error analyzing object:', error);
    res.status(500).json({
      error: "We couldn't analyze this object right now. Please try again or provide a short description."
    });
  }
});

// Blueprint Generation API (Step 4 -> Step 5)
app.post('/api/generate-blueprint', async (req, res) => {
  try {
    const { ideaId, objectName, material } = req.body;
    const blueprint = await generateBlueprint({ ideaId, objectName, material });
    res.json(blueprint);
  } catch (error) {
    console.error('Error generating blueprint:', error);
    res.status(500).json({
      error: "Failed to generate instructions for this project. Please try again."
    });
  }
});

// Personal AI Assistant Chat API
app.post('/api/assistant-chat', async (req, res) => {
  try {
    const { message, history } = req.body;
    if (!message || message.trim().length === 0) {
      return res.status(400).json({ error: "Please provide a question or topic." });
    }
    const result = await chatWithAssistant({ message, history });
    res.json(result);
  } catch (error) {
    console.error('Error in assistant chat:', error);
    res.status(500).json({
      reply: "I'm having trouble connecting right now, but feel free to explore our step-by-step guides or check the materials section!",
      source: 'fallback'
    });
  }
});

// Projects API
app.get('/api/projects', requireAuth, async (req, res) => {
  try {
    const projects = await getAllProjects(req.userId);
    res.json(projects);
  } catch (error) {
    console.error('Error reading projects:', error);
    res.status(500).json({ error: "Failed to load projects." });
  }
});

app.get('/api/projects/:id', requireAuth, async (req, res) => {
  try {
    const project = await getProjectById(req.params.id, req.userId);
    if (!project) {
      return res.status(404).json({ error: "Project not found." });
    }
    res.json(project);
  } catch (error) {
    console.error('Error fetching project:', error);
    res.status(500).json({ error: "Failed to fetch project." });
  }
});

app.post('/api/projects', requireAuth, async (req, res) => {
  try {
    const projectData = req.body;
    if (!projectData.newProduct || !projectData.originalObject) {
      return res.status(400).json({ error: "Missing required project details." });
    }
    const created = await createProject(req.userId, projectData);
    res.status(201).json(created);
  } catch (error) {
    console.error('Error saving project:', error);
    res.status(500).json({ error: "Failed to save project." });
  }
});

app.patch('/api/projects/:id', requireAuth, async (req, res) => {
  try {
    const updated = await updateProject(req.params.id, req.userId, req.body);
    if (!updated) {
      return res.status(404).json({ error: "Project not found." });
    }
    res.json(updated);
  } catch (error) {
    console.error('Error updating project:', error);
    res.status(500).json({ error: "Failed to update project." });
  }
});

app.delete('/api/projects/:id', requireAuth, async (req, res) => {
  try {
    const success = await deleteProject(req.params.id, req.userId);
    if (!success) {
      return res.status(404).json({ error: "Project not found." });
    }
    res.json({ success: true, message: "Project deleted." });
  } catch (error) {
    console.error('Error deleting project:', error);
    res.status(500).json({ error: "Failed to delete project." });
  }
});

// Explore Inspiration API
app.get('/api/explore', (req, res) => {
  try {
    const exploreFile = path.join(__dirname, 'data', 'exploreData.json');
    let items = [];
    if (fs.existsSync(exploreFile)) {
      items = JSON.parse(fs.readFileSync(exploreFile, 'utf-8'));
    }

    const { category, search } = req.query;

    if (category && category !== 'all') {
      items = items.filter(item => item.category.toLowerCase() === category.toLowerCase());
    }

    if (search && search.trim() !== '') {
      const q = search.toLowerCase();
      items = items.filter(item =>
        item.originalObject.toLowerCase().includes(q) ||
        item.newProduct.toLowerCase().includes(q) ||
        item.material.toLowerCase().includes(q) ||
        item.description.toLowerCase().includes(q)
      );
    }

    res.json(items);
  } catch (error) {
    console.error('Error fetching explore items:', error);
    res.status(500).json({ error: "Failed to fetch inspiration catalog." });
  }
});

// Serve static files from Vite build in production
const distPath = path.join(__dirname, '..', 'dist');
if (fs.existsSync(distPath)) {
  app.use(express.static(distPath));
  app.get('*', (req, res, next) => {
    if (req.path.startsWith('/api')) {
      return next();
    }
    res.sendFile(path.join(distPath, 'index.html'));
  });
}

app.listen(PORT, () => {
  console.log(`RE:BOX backend server running on http://localhost:${PORT}`);
});
