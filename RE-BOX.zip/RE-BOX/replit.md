# RE:BOX on Replit

## Run the app

The preview runs the Vite client on port 5000 and the Express API on port 3001:

```bash
PORT=3001 npm run server & npm run dev -- --host 0.0.0.0 --port 5000
```

For a production-style local run, build the client and start Express:

```bash
npm run build
npm start
```

## Authentication

RE:BOX uses Replit-managed Clerk sessions. Sign-in and sign-up are served at
`/sign-in` and `/sign-up`; the API requires a valid session for project data.
Enable Google as a sign-in provider in the workspace Auth pane if it is not
already enabled. Never restore the old demo login endpoints or store sessions in
local storage.

## Persistent project storage

Saved projects live in the managed PostgreSQL database in the
`rebox_projects` table. Each row is scoped to the Clerk user ID; every read,
update, and delete must include that owner ID. The development schema has been
created. Do not add startup-time schema creation; Replit's Publish flow handles
managed production schema changes.

## AI and inspiration data

The maker assistant and object-analysis taxonomy work without an external key.
Setting `GEMINI_API_KEY` through Replit Secrets enables Gemini-powered image
analysis and chat; do not commit or hard-code the key. The Explore catalog is
maintained in `server/data/exploreData.json`.