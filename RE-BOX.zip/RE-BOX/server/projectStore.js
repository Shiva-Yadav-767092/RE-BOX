import { randomUUID } from 'node:crypto';
import pg from 'pg';

const { Pool } = pg;

if (!process.env.DATABASE_URL) {
  throw new Error('DATABASE_URL is required to store RE:BOX projects.');
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

export async function getAllProjects(ownerId) {
  const { rows } = await pool.query(
    'SELECT project_data FROM rebox_projects WHERE owner_id = $1 ORDER BY created_at DESC',
    [ownerId]
  );
  return rows.map((row) => row.project_data);
}

export async function getProjectById(id, ownerId) {
  const { rows } = await pool.query(
    'SELECT project_data FROM rebox_projects WHERE id = $1 AND owner_id = $2',
    [id, ownerId]
  );
  return rows[0]?.project_data || null;
}

export async function createProject(ownerId, projectData) {
  const now = new Date().toISOString();
  const steps = Array.isArray(projectData.steps) ? projectData.steps : [];
  const completedStepsCount = steps.filter((step) => step.completed).length;
  const project = {
    ...projectData,
    id: randomUUID(),
    createdAt: now,
    updatedAt: now,
    completedAt: projectData.status === 'Completed' ? now : null,
    completedStepsCount,
    totalStepsCount: steps.length,
  };

  await pool.query(
    'INSERT INTO rebox_projects (id, owner_id, project_data) VALUES ($1, $2, $3::jsonb)',
    [project.id, ownerId, JSON.stringify(project)]
  );
  return project;
}

export async function updateProject(id, ownerId, updates) {
  const current = await getProjectById(id, ownerId);
  if (!current) return null;

  const safeUpdates = { ...updates };
  delete safeUpdates.id;
  delete safeUpdates.createdAt;
  delete safeUpdates.ownerId;

  const updated = {
    ...current,
    ...safeUpdates,
    id: current.id,
    createdAt: current.createdAt,
    updatedAt: new Date().toISOString(),
  };

  if (Array.isArray(updated.steps)) {
    updated.completedStepsCount = updated.steps.filter((step) => step.completed).length;
    updated.totalStepsCount = updated.steps.length;
    if (
      updates.status !== 'In Progress' &&
      updated.totalStepsCount > 0 &&
      updated.completedStepsCount === updated.totalStepsCount
    ) {
      updated.status = 'Completed';
      updated.completedAt ||= updated.updatedAt;
    }
  }

  if (updates.status === 'Completed') {
    updated.completedAt ||= updated.updatedAt;
  } else if (updates.status === 'In Progress') {
    updated.completedAt = null;
  }

  const { rowCount } = await pool.query(
    'UPDATE rebox_projects SET project_data = $3::jsonb, updated_at = NOW() WHERE id = $1 AND owner_id = $2',
    [id, ownerId, JSON.stringify(updated)]
  );
  return rowCount ? updated : null;
}

export async function deleteProject(id, ownerId) {
  const { rowCount } = await pool.query(
    'DELETE FROM rebox_projects WHERE id = $1 AND owner_id = $2',
    [id, ownerId]
  );
  return rowCount > 0;
}

export async function closeProjectStore() {
  await pool.end();
}